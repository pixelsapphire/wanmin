package com.pixelsapphire.wanmin.controller;

import com.pixelsapphire.wanmin.DatabaseException;
import com.pixelsapphire.wanmin.Wanmin;
import com.pixelsapphire.wanmin.data.DictTuple;
import com.pixelsapphire.wanmin.data.WanminCollection;
import com.pixelsapphire.wanmin.data.records.*;
import org.jetbrains.annotations.NotNull;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

@SuppressWarnings("SqlSourceToSinkFlow")
public class WanminDBController {

    private final @NotNull String username;
    private final Connection connection;
    public final WanminCollection<Contractor> contractors = new WanminCollection<>(
            Contractor::fromRecord, Contractor::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_kontrahenci"),
            r -> execute("INSERT INTO sbd147412.wm_kontrahenci (nazwa, adres, telefon, email, NIP) VALUES ('%s', '%s', '%s', '%s', '%s')",
                         r.getString("nazwa"), r.getString("adres"), r.getOptionalString("telefon").orElse(null),
                         r.getOptionalString("email").orElse(null), r.getOptionalString("NIP").orElse(null)));
    public final WanminCollection<Product> products = new WanminCollection<>(
            Product::fromRecord, Product::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_produkty"),
            r -> execute("INSERT INTO sbd147412.wm_produkty (nazwa, jednostka) VALUES ('%s', '%s')",
                         r.getString("nazwa"), r.getOptionalString("jednostka").orElse(null)));
    public final WanminCollection<ForeignInvoice> foreignInvoices = new WanminCollection<>(
            (in) -> ForeignInvoice.fromRecord(in, contractors,
                                              id -> execute("SELECT * FROM sbd147412.wm_faktury_obce_pozycje WHERE faktura = %d", id)
                                                      .stream().map((it) -> ForeignInvoiceItem.fromRecord(it, products)).toList()),
            ForeignInvoice::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_faktury_obce"),
            r -> execute("INSERT INTO sbd147412.wm_faktury_obce (kontrahent, data, nr_obcy) VALUES ('%d', '%s','%s')",
                         r.getInt("kontrahent"), r.getDate("data"), r.getString("nr_obcy")),
            this.execute();
    public final WanminCollection<StorageItem> storage = new WanminCollection<>(
            (r) -> StorageItem.fromRecord(r, products, foreignInvoices), StorageItem::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_magazyn"),
            r -> execute("INSERT INTO sbd147412.wm_magazyn (produkt, ilosc, data_waznosci, faktura) VALUES ('%d','%d','%s','%d')",
                         r.getInt("produkt"), r.getInt("data_waznosci"), r.getOptionalDate("data_waznosci").orElse(null), r.getInt("faktura")));
    public final WanminCollection<Recipe> recipes = new WanminCollection<>(
            (r) -> Recipe.fromRecord(r, id -> execute("SELECT * FROM sbd147412.wm_przepisy_skladniki WHERE przepis = %d", id)
                    .stream().map((it) -> RecipeIngredient.fromRecord(it, products)).toList()),
            Recipe::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_przepisy"),
            r -> execute("INSERT INTO sbd147412.wm_przepisy (nazwa) VALUES ('%s')", r.getString("nazwa")));
    private final Provider<MenuItem> menuItemProvider = id -> execute("SELECT * FROM sbd147412.wm_menu_pozycje WHERE id = %d", id)
            .stream().map((r) -> MenuItem.fromRecord(r, recipes)).findFirst().orElseThrow();
    private final Provider<List<OrderItem>> orderItemsProvider = id -> execute("SELECT * FROM sbd147412.wm_zamowienia_pozycje WHERE zamowienie = %d", id)
            .stream().map(r -> OrderItem.fromRecord(r, menuItemProvider)).toList();
    private final Provider<List<MenuItem>> menuItemsProvider = id -> execute("SELECT * FROM sbd147412.wm_menu_pozycje WHERE menu = %d", id)
            .stream().map((r) -> MenuItem.fromRecord(r, recipes)).toList();
    public final WanminCollection<Menu> menus = new WanminCollection<>(
            (r) -> Menu.fromRecord(r, menuItemsProvider), Menu::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_menu"),
            r -> execute("INSERT INTO sbd147412.wm_menu (nazwa) VALUES ('%s')", r.getString("nazwa")));
    public final WanminCollection<Customer> customers = new WanminCollection<>(
            Customer::fromRecord, Customer::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_klienci"),
            //przy tworzeniu klientow punkty automatycznie ustawiane są na 0 w bazie danych
            r -> execute("INSERT INTO sbd147412.wm_klienci (imie, nazwisko) VALUES ('%s', '%s')",
                         r.getString("imie"), r.getString("nazwisko")));
    public final WanminCollection<Position> positions = new WanminCollection<>(
            Position::fromRecord, Position::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_stanowiska"),
            r -> execute("INSERT INTO sbd147412.wm_stanowiska (nazwa, pensja) VALUES ('%s', '%f')",
                         r.getString("nazwa"), r.getFloat("pensja")));
    public final WanminCollection<Employee> employees = new WanminCollection<>(
            Employee::fromRecord, Employee::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_pracownicy"),
            r -> execute("INSERT INTO sbd147412.wm_pracownicy (imie, nazwisko, login) VALUES ('%s', '%s', '%s')",
                         r.getString("imie"), r.getString("nazwisko"), r.getOptionalString("login").orElse(null)));
    public final WanminCollection<EmploymentContract> employmentContracts = new WanminCollection<>(
            (r) -> EmploymentContract.fromRecord(r, employees, positions), EmploymentContract::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_umowy"),
            r -> execute("INSERT INTO sbd147412.wm_umowy (numer, typ, pracownik, stanowisko, zawiazana) VALUES ('%s', '%s', '%d', '%d', '%s')",
                         r.getString("numer"), r.getString("typ"), r.getInt("pracownik"), r.getInt("stanowisko"), r.getDate("zawiazana")));
    public final WanminCollection<Order> orders = new WanminCollection<>(
            (r) -> Order.fromRecord(r, employees, customers, orderItemsProvider), Order::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_zamowienia"),
            r -> execute("INSERT INTO sbd147412.wm_zamowienia (stolik, kelner, czas, klient, czy_zaplacone) VALUES ('%d','%d','%s','%d','%s')",
                         r.getInt("stolik"), r.getInt("kelner"), r.getDate("czas"), r.getInt("klient"), r.getBoolean("czy_zaplacone")));
    public final WanminCollection<Invoice> invoices = new WanminCollection<>(
            (r) -> Invoice.fromRecord(r, customers, orders), Invoice::toRecord,
            () -> execute("SELECT * FROM sbd147412.wm_faktury"),
            r -> execute("INSERT INTO sbd147412.wm_faktury (klient, zamowienie, data, nr_faktury, znizka) VALUES ('%d','%d','%s','%s','%f')",
                         r.getInt("klient"), r.getInt("zamowienie"), r.getString("data"), r.getString("nr_faktury"), r.getFloat("znizka")));

    public WanminDBController(@NotNull String username, char[] password) {
        this.username = username;
        this.connection = createConnection("jdbc:oracle:thin", "admlab2.cs.put.poznan.pl", 1521,
                                           "dblab03_students.cs.put.poznan.pl", username, password);
    }

    @SuppressWarnings("SameParameterValue")
    private static @NotNull Connection createConnection(@NotNull String driver, @NotNull String host, int port, @NotNull String service,
                                                        @NotNull String username, char @NotNull [] password) {
        final var connectionProps = new Properties();
        connectionProps.put("user", username);
        connectionProps.put("password", new String(password));
        DriverManager.setLoginTimeout(5);
        try {
            final var connection = DriverManager.getConnection(driver + ":@//" + host + ":" + port + "/" + service, connectionProps);
            Logger.getLogger(Wanmin.class.getName()).log(Level.INFO, "Połączono z bazą danych");
            return connection;
        } catch (SQLException e) {
            throw new DatabaseException("Nie udało się połączyć z bazą danych", e);
        }
    }

    public @NotNull String getUsername() {
        return username;
    }

    public int getEmployeeId() {
        return execute("SELECT sbd147412.wm_my_id('%s') AS id FROM dual", username.toUpperCase()).getFirst().getInt("id");
    }

    public boolean isRoleEnabled(@NotNull String role) throws DatabaseException {
        final var firstRecord = execute("SELECT sbd147412.wm_rola_przyznana('%s') AS przyznana FROM dual",
                                        role.toUpperCase()).getFirst();
        final var granted = firstRecord.getBoolean("przyznana");
        if (granted) execute("SET ROLE %s", role.toUpperCase());
        return granted;
    }

    public @NotNull List<DictTuple> execute(@NotNull String query, Object... parameters) {
        try (final var statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {
            final String sql = String.format(query, parameters);
            try (final var result = statement.executeQuery(sql)) {
                final List<DictTuple> list = new ArrayList<>();
                while (result.next()) list.add(DictTuple.from(result));
                return list;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Nie udało się wykonać zapytania", e);
        }
    }
}
