package com.pixelsapphire.wanmin.data;

import com.pixelsapphire.wanmin.controller.Provider;
import com.pixelsapphire.wanmin.data.records.DatabaseRecord;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class WanminCollection<T extends DatabaseRecord> implements Provider<T> {

    private final @NotNull Function<DictTuple, T> objectFactory;
    private final @NotNull Function<T, DictTuple> recordFactory;

    private final @NotNull Supplier<List<DictTuple>> databaseAccessor;
    private final @NotNull Consumer<DictTuple> recordSaver;

    public WanminCollection(@NotNull Function<DictTuple, T> objectFactory, @NotNull Function<T, DictTuple> recordFactory,
                            @NotNull Supplier<List<DictTuple>> dataSelector, @NotNull Consumer<DictTuple> dataInserter) {
        this.objectFactory = objectFactory;
        this.databaseAccessor = dataSelector;
        this.recordFactory = recordFactory;
        this.recordSaver = dataInserter;
    }

    public @NotNull Stream<T> getAll() {
        return databaseAccessor.get().stream().map(objectFactory);
    }

    public @NotNull Stream<T> getAllWhere(@NotNull Predicate<T> predicate) {
        return getAll().filter(predicate);
    }

    public @NotNull T getFirstWhere(@NotNull Predicate<T> predicate) {
        return getAll().filter(predicate).findFirst().orElseThrow();
    }

    @Override
    public @NotNull T getById(int id) {
        return getAll().filter(record -> record.getId() == id).findFirst().orElseThrow();
    }

    public void add(@NotNull T object) {
        recordSaver.accept(recordFactory.apply(object));
    }
}